![Wings-Web-TV](images/banner.jpg)
# Wings-Web-TV-M3u8
![Wings-Web-TV](https://img.shields.io/github/issues/alasarjadeed/Wings-Web-TV-M3u8) ![Wings-Web-TV](https://img.shields.io/github/forks/alasarjadeed/Wings-Web-TV-M3u8) ![Wings-Web-TV](https://img.shields.io/github/stars/alasarjadeed/Wings-Web-TV-M3u8) ![Wings-Web-TV](https://img.shields.io/github/license/alasarjadeed/Wings-Web-TV-M3u8) ![Wings-Web-TV](https://img.shields.io/badge/version-8.2.0-green)  
Easy way to listen to music or radio stations, watch movies, series, animes, shows, porn or IPTV, read novel or manga books and play games on the website. 

# Official
 [Demo](https://github.com/alasarjadeed/Wings-Web-TV-M3u8/)  

# Sponsor
 [![Wings-Web-TV](images/buymecoffeesponsor.jpeg)](https://www.youtube.com/c/WORLDALASRTECHNOLOGY)

# Version
![Wings-Web-TV](https://img.shields.io/badge/version-8.2.0-green)  
  - Support to select countries, languages and category to watch more than 6000 TV channels
  - Support to search and watch movies, series, animes and show
  - Support to search and listen to 28000+ radio stations
  - Support to search and watch porn videos if you open sensitive content
  - Support to watch m3u8 links video
  - Support to search and listen to music
  - Support to search and read books
  - Support to search and read manga
  - Support to play games
  - Support to remark your favorite channels, movies, series...
  - Support to control and select source websites
  - more...  

# Screenshot
![Wings-Web-TV](images/example.jpg)  

# Thanks
  - [jQuery](https://github.com/jquery/jquery)
  - [iptv-org](https://github.com/iptv-org/iptv)
  - [Radiobrowser](https://github.com/segler-alex/radiobrowser-api-rust)
  - [Videojs](https://github.com/videojs/video.js)
  - [Spotlight](https://github.com/nextapps-de/spotlight)  
  
# License
![Wings-Web-TV](https://img.shields.io/github/license/alasarjadeed/Wings-Web-TV-M3u8)  
Permissions of this weak copyleft license are conditioned on making available source code of licensed files and modifications of those files under the same license (or in certain cases, one of the GNU licenses). Copyright and license notices must be preserved. Contributors provide an express grant of patent rights. However, a larger work using the licensed work may be distributed under different terms and without source code for files added in the larger work.
